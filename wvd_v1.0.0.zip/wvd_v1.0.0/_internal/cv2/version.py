opencv_version = "4.11.0.86"
contrib = False
headless = False
rolling = False
ci_build = True